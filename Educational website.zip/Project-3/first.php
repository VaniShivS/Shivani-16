<!DOCTYPE HTML>
<html>
<head>
  <title>Register Form</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
 <!-- <link rel="stylesheet" href="style.css">-->
  <style>
    body {
      background-image: url(picture/flower-8054861_1280.webp);
      height: 100%;
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }

    .container {
      margin-top: 50px;
      background-color: rgba(255, 255, 255, 0.8);
      padding: 20px;
      border-radius: 10px;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-label {
      font-weight: bold;
    }

    .bg-image {
      background-image: url(picture/flower-8054861_1280.webp);
      background-size: cover;
      background-position: center;
      height: 100vh;
    }
  </style>
</head>

<body>
  <div class="container">
    <form action="insert.php" method="POST">
      <div class="form-group">
        <label class="form-label" for="username">Name :</label>
        <input type="text" class="form-control" name="username" required>
      </div>
      <div class="form-group">
        <label class="form-label" for="password">Password :</label>
        <input type="password" class="form-control" name="password" required>
      </div>
      <div class="form-group">
        <label class="form-label">Gender :</label>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gender" value="m" required>
          <label class="form-check-label">Male</label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="gender" value="f" required>
          <label class="form-check-label">Female</label>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label" for="email">Email :</label>
        <input type="email" class="form-control" name="email" required>
      </div>
      <div class="form-group">
        <label class="form-label" for="phoneCode">Phone no :</label>
        <div class="input-group">
          <select class="form-select" name="phoneCode" required>
            <option selected hidden value="">Select Code</option>
            <option value="91">91</option>
            <option value="92">92</option>
            <option value="93">93</option>
            <option value="94">94</option>
            <option value="95">95</option>
            <option value="96">96</option>
          </select>
          <input type="phone" class="form-control" name="phone" required>
        </div>
      </div>
      <div class="form-group">
        <input type="submit" class="btn btn-primary" value="Submit" name="submit">
      </div>
    </form>
  </div>
</body>
</html>
