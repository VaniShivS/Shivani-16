<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enroll Now</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #d5ebe9;
            background-image: url(img/login.jpg);
            height: 100%;
            background-size: cover;
            background-position: absolute;
            background-repeat: no-repeat;
        }
        .enroll-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }   
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="enroll-container">
            <h2 class="mb-4">Enroll Now</h2>
            <form>
                <div class="mb-3">
                    <label for="full-name" class="form-label">Full Name</label>
                    <input type="text" class="form-control" id="full-name" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" required>
                </div>
                <div class="mb-3">
                    <label for="course" class="form-label">Select Course</label>
                    <select class="form-select" id="course" required>
                        <option value="" disabled selected>Select a course...</option>
                        <option value="course1">Digital Marketing Mastery</option>
                        <option value="course2">Creative Writing Workshop</option>
                        <option value="course3">Entrepreneurship Bootcamp</option>
                        <option value="course3">Data Science Essentials</option>
                        <option value="course3">Artificial Intelligence Fundamentals</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Enroll Now</button>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS (optional, for enhanced functionality) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                       