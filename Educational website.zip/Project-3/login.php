<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-color: #d5ebe9;
            background-image: url(img/page.jpg);
            height: 100%;
            background-size: cover;
            background-position: absolute;
            background-repeat: no-repeat;
        }
    </style>
</head>
<body class="bg-light">
    <div class="login-container">
        <div class="row justify-content-center login-container">
            <div class="class col-md-4">
                <div class="card shadow-lg mt-5">
                    <div class="card-header text-bg-primary">Login</div>
                    <div class="card-body">
                      <form>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="user_name" placeholder="jphndoe" autofocus>
                            <label for="user_name">Username</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="pass_word" placeholder="****">
                            <label for="pass_word">password</label>
                        </div>
                        <div class="form-check mb-3">
                            <input type="checkbox" class="form-check-input" form="remember_me">
                            <label for="remember_me" class="form-check-label">
                                Remember me
                            </label>
                        </div>
                        <div class="d-grid">
                            <button class="btn btn-success" type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
                                    <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
                                </svg>
                                Login to continue
                            </button>
                        </div>
                      </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
