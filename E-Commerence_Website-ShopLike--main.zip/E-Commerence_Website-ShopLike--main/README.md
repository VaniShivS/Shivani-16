# E-Commerence_Website-ShopKaro-
E-commerce Website built using HTML and CSS
Here I have made a shopping website using only HTML and CSS. I haven't used any Javascript 
But if we don't use the javascript in our project then our website will be static website as it can't do dynamic things
As we all know all the three components (HTML, CSS, JavaScript) plays an important role in building an application.
If we take an exaple of car then the body of a car(or the skleton) is like HTML
Paint of the car is Acting like CSS as it gives appreance to the car
And The Engine in the car plays an important role as if the car has no engine than the car can't move. Thats the role oj JavaScript in project.
Most of the user prefer JavaScript beacause it can used as both for frontend as well as for backend.
Various framework are also available like React, Angular.
Clone the Repo and Enjoy the website
Thankyou
